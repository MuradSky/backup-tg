import styled from "styled-components"

const StyledRow = styled.div`
    display: flex;
    align-items: ${({ align }) => align};
    justify-content: ${({ justyfy }) => justyfy};
`

const Row = ({
    children,
    className = '',
    align = 'center',
    justyfy = 'space-between',
    onClick,
}) => {
    return (
        <StyledRow
            align={align}
            justyfy={justyfy}
            className={className}
            onClick={onClick}
        >
            {children}
        </StyledRow>
    )
}

export default Row