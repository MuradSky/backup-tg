import Row from '../common/Row'
import './FunExpress.scss'
import express from '../../assets/img/fun-express.svg'

const FunExpress = () => {
    return (
        <Row className='express'>
            <img alt='logo' className='express__pic' src={express} />
        </Row>
    )
}

export default FunExpress
