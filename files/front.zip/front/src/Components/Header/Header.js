import Row from '../common/Row'
import './Header.scss'
import Logo from '../../assets/img/logo.svg'
import Popup from '../Popup/Popup'
import RegistrationPopup from '../Popup/RegistrationPopup/RegistrationPopup'
import PromocodePopup from '../Popup/PromocodePopup/PromocodePopup'
import RightPopup from '../RightPopup/RightPopup'

const Header = () => {
    return (
        <Row className='header'>
            <Row className='header__left' justyfy='flex-start'>
                <button className='coupon' />
                <RightPopup content={<></>}><button className='cart' /></RightPopup>
            </Row>
            <img alt='logo' className='header__logo' src={Logo} />
            <Row className='header__right' justyfy='flex-end'>
                <Popup content={<PromocodePopup />} classes='promocode' align='flex-start'>
                    <button className='promocode' />
                </Popup>
                <Popup content={<RegistrationPopup />} classes='registration'>
                    <button className='account' />
                </Popup>
            </Row>
        </Row>
    )
}

export default Header
