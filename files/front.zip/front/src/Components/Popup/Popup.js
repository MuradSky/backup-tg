import { createPortal } from 'react-dom'
import './Popup.scss'
import { useState } from 'react'
import Row from '../common/Row';
import Column from '../common/Column';
import classNames from 'classnames';

const Popup = ({ children, content, classes = '', align = 'center' }) => {
    const [showModal, setShowModal] = useState(false);
    const popupClasses = classNames('popup__content', classes)
    return (
        <>
            <div className='popup__button' onClick={() => setShowModal(true)}>
                {children}
            </div>
            {showModal && createPortal( 
                <Row
                    className='popup__layout'
                    align='center'
                    justyfy='center'
                >
                    <Column align={align} className={popupClasses}>
                        <>
                            <button
                                onClick={() => setShowModal(false)}
                                className='popup__close'
                            />
                            {content}
                        </>
                    </Column>
                </Row>,
                document.body
            )}
        </>
    );
}

export default Popup
