import './RegistrationPopup.scss'
import Row from '../../common/Row';

const RegistrationPopup = () => {
    return (
        <>
            <span className='registration__title'>Привет!</span>
            <span className='registration__article'>
                Добро пожаловать в торгово-увлекательный<br/>
                парк Fun Express! Заполни форму<br/>
                регистрации, чтобы получить свой билет<br/>
                в мир приключений и ярких эмоций!<br/>
            </span>
            <Row className='registration__signin'>
                <button className='registration__signin_btn'>
                    Зарегистрироваться
                </button>
            </Row>
            <Row className='registration__login'>
                <button className='registration__login_btn' />
            </Row>
        </>
);
}

export default RegistrationPopup
