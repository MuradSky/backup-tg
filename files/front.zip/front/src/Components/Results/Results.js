import cn from 'classnames';
import Column from '../common/Column';
import Row from '../common/Row';

import './Results.scss';
import hint from '../../assets/img/results-hint.svg'
import smarphone from '../../assets/img/category-smartphone.svg'
import tech from '../../assets/img/category-tec.svg'
import shoes from '../../assets/img/category-shoes.svg'
import toys from '../../assets/img/category-toys.svg'
import clothes from '../../assets/img/category-clothes.svg'
import topSales from '../../assets/img/results-top.png'
import { useState } from 'react';

const itemCards = [smarphone, tech, toys, clothes, shoes]

const TOP_CATEGORIES = 'topCategories'
const DAY_PRODUCT = 'dayProduct'

function Results() {
  const [selectedChapter, setSelectedChapter] = useState(TOP_CATEGORIES)
  const categoriesClasses = cn(
    'results__select_btn',
    { selected: selectedChapter === TOP_CATEGORIES }
  )
  const productClasses = cn(
    'results__select_btn',
    { selected: selectedChapter === DAY_PRODUCT }
  )
  return (
    <Column className='results'>
        <Row className='results__title'>
            <span>Результаты 11.11</span>
            <div className='hint'>
              <img
                className='hint__text'
                src={hint}
                alt='hint'
              />
            </div>
        </Row>
        <Row className='results__select'>
            <button
              className={categoriesClasses}
              onClick={() => setSelectedChapter(TOP_CATEGORIES)}
            >
              Топ категорий
            </button>
            <button
              className={productClasses}
              onClick={() => setSelectedChapter(DAY_PRODUCT)}
            >
              Товар дня
            </button>
        </Row>
        <div className='results__items'>
          {selectedChapter === TOP_CATEGORIES && itemCards.map((src, i) => (
            <img className='categories__card' src={src} alt='item' key={i} />
          ))}

          {selectedChapter === DAY_PRODUCT && (
            <Row className='dayproduct' justyfy='center' align='flex-end'>
              <button className='dayproduct__btn'>Смотреть товар</button>
            </Row>
          )}

          <Column align='flex-start' justyfy='space-between' className='total__gmv'>
            <span className='total__title'>GMV</span>
            <span className='total__sum'>115 356 556 ₽</span>
          </Column>
          <Column align='flex-start' justyfy='space-between'  className='total__orders'>
            <span className='total__title'>Созданные заказы</span>
            <span className='total__sum'>120 000 455</span>
          </Column>
          <Column align='flex-start' justyfy='space-between'  className='total__aov'>
            <span className='total__title'>Созданные заказы</span>
            <span className='total__sum'>20 500 ₽</span>
          </Column>
          <img src={topSales} alt='top' className='results__top' />
        </div>
    </Column>
  );
}

export default Results;
