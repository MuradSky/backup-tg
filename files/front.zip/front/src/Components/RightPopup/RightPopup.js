import { createPortal } from 'react-dom'
import Select from 'react-select'
import './RightPopup.scss'
import Union from '../../assets/img/cart-union.png'
import UnionW from '../../assets/img/cart-union-white.png'
import { useState } from 'react'
import Row from '../common/Row';
import Column from '../common/Column';
import classNames from 'classnames';
import CartItem from '../Cart/CartItem'

const items = [
    {
        name: 'Умные часы Amazfit GTS',
        id: 1,
        isOnline: true,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 2,
        isOnline: true,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 3,
        isOnline: false,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 4,
        isOnline: false,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 5,
        isOnline: true,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 6,
        isOnline: true,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 7,
        isOnline: false,
        price: 480
    },
    {
        name: 'Умные часы Amazfit GTS',
        id: 8,
        isOnline: false,
        price: 480
    }
]

const titles = {
    cart: 'Корзина',
    order: 'Оформление',
    ordered: 'Заказ оформлен'
}

const states = {
    CART: 'cart',
    ORDER: 'order',
    ORDERED: 'ordered'
}

const deliveries = {
    PICKPOINT: 'pickpoint',
    DELIVERY: 'delivery',
    ONLINE: 'online'
}

const selectOptions = [
    { label: 'Москва, Пресненская наб., 10, 11 этаж', value: 'Chocolate' },
    { label: 'Ташкент, ул. Инжобод, 32б 2 этаж (коворкинг Ziyookline)', value: 'Strawberry' },
    { label: 'Нижний Новгород, ул. Нартова, 6', value: 'Vanilla' }
  ]

const RightPopup = ({ children, content, classes = '', align = 'center' }) => {
    const [currentState, setCurrentState] = useState('cart')
    const [delivery, setDelivery] = useState(deliveries.DELIVERY)
    const [showModal, setShowModal] = useState(false);
    const [adress, setAdress] = useState(selectOptions[0]);
    const [allItems, setAllItems] = useState(items)
    const [selectedItems, setSelectedItems] = useState([])
    const selected = allItems.filter(({ id }) => selectedItems.some((n) => n === id))
    const totalSum = selected.reduce((acc, item) => {
        return acc + item.price
    }, 0) 
    const coins = 1440
    const onRemove = (itemId) => () => setAllItems((items) => items.filter(({ id }) => id !== itemId))
    const onCheck = (itemId, checked) => {
        if (!checked && selectedItems.some((el) => el === itemId)) {
            const filtered = selectedItems.filter((id) => id !== itemId)
            setSelectedItems(filtered)
        } else {
            setSelectedItems([...selectedItems, itemId])
        }
    }
    const isDisabled = () => {
        return totalSum > coins
    }

    const onOrder = () => {
        if (currentState === states.CART) {
            setCurrentState(states.ORDER)
        } else if (currentState === states.ORDER) {
            setCurrentState(states.ORDERED)
        } else {
            setShowModal(false)
            setCurrentState(states.CART)
        }
    }
    const popupClasses = classNames('popup-right__content', classes)
    return (
        <>
            <div className='popup-right__button' onClick={() => setShowModal(true)}>
                {children}
            </div>
            {showModal && createPortal(
                <Row
                    className='popup__layout'
                    align='flex-start'
                    justyfy='flex-end'
                >
                    <Column align={align} justyfy='space-between' className={popupClasses}>
                        <Row justify='space-between' className='popup-right__top'>
                            <Row>
                                <span className='popup-right__title'>{titles[currentState]}</span>
                                {currentState !== states.ORDERED && <><span className='popup-right__divider'></span>
                                <span className='popup-right__have'>У вас: </span>
                                <img className='popup-right__union' src={Union} alt='union' />
                                <span className='popup-right__total'>{coins}</span></>}
                            </Row>
                            <button
                                onClick={() => setShowModal(false)}
                                className='popup-right__close'
                            />
                        </Row>
                        {currentState === states.CART && <Column className='popup-right__items' align='flex-start'>
                            {allItems.map((item, i) => <CartItem item={item} key={i} onRemove={onRemove(item.id)} onCheck={onCheck} />)}
                        </Column>}
                        {currentState === states.ORDER && <Column className='order' align='flex-start'>
                            <div className='order__person'>
                                <input className='order__input' placeholder='Иван Иванов'></input>
                                <input className='order__input' placeholder='corporateemail@gmail.com' type='email'></input>
                            </div>
                            <Column  className='order__delivery'align='flex-start'>
                                <Row>
                                    <input type='radio' className='order__checkbox' checked={delivery === deliveries.PICKPOINT} onChange={() => setDelivery(deliveries.PICKPOINT)} />
                                    <span className='order__checkbox_text'>Забрать заказ из офиса Aliexpress</span>
                                </Row>
                                <Row>
                                    <input type='radio' className='order__checkbox' checked={delivery === deliveries.DELIVERY} onChange={() => setDelivery(deliveries.DELIVERY)} />
                                    <span className='order__checkbox_text'>Доставка курьером (по России)</span>
                                </Row>
                            </Column>
                            {delivery === deliveries.DELIVERY && <div className='delivery'>
                                <input className='delivery__name order__input' placeholder='ФИО получателя'></input>
                                <input className='delivery__city order__input' placeholder='Город, улица'></input>
                                <input className='delivery__home order__input' placeholder='Дом'></input>
                                <input className='delivery__appart order__input' placeholder='Квартира'></input>
                                <input className='delivery__zip order__input' placeholder='Индекс'></input>
                                <input className='delivery__phone order__input' type='tel' placeholder='Контактный телефон'></input>
                            </div>}
                            {delivery === deliveries.PICKPOINT && <div className='delivery'>
                                <Select
                                    styles={{
                                        indicatorSeparator: (styles) => ({ ...styles, display: 'none' }),
                                        control: (styles) => ({
                                            ...styles,
                                            textAlign: 'start',
                                            borderWidth: '0',
                                            outline: 'none',
                                            background: '#F6F8FF',
                                            height: '100%',
                                            padding: '0 32px'
                                        }),
                                        option: (styles) => ({
                                            ...styles,
                                            textAlign: 'start',
                                            height: '74px',
                                            background: '#F6F8FF',
                                            color: '#666666',
                                            padding: '28px 32px'
                                        }),
                                        menu: (styles) => ({
                                            ...styles,
                                            background: '#F6F8FF',
                                        })
                                    }}
                                    className='delivery__select'
                                    classNames={{
                                        control: (state) =>
                                        state.isFocused ? 'select__focused' : '',
                                    }}
                                    options={selectOptions}
                                    defaultValue={selectOptions[0]}
                                    onChange={setAdress}
                                />
                            </div>}
                        </Column>}
                        {currentState === states.ORDERED && <Column className='ordered' align='flex-start'>
                            {delivery === deliveries.DELIVERY && <div className='ordered__text'>
                                Заказ успешно оформлен, спасибо!<br/>
                                Детали о заказе и код для отслеживания<br/>
                                посылки пришлём на твою корпоративную<br/>
                                почту совсем скоро
                            </div>}
                            {delivery === deliveries.PICKPOINT && <>
                                <div className='ordered__text'>
                                    Заказ успешно оформлен, спасибо! Забрать<br/>
                                    свои оффлайн-товары ты можешь с 28<br/>
                                    ноября в нашем офисе по адресу:<br/>
                                </div>
                                <span className='ordered__adress'>{adress.label}</span>
                                <div className='ordered__text'>
                                    А все детали об онлайн-товарах мы<br/>
                                    пришлём на твою корпоративную<br/>
                                    почту совсем скоро<br/>
                                </div>
                            </>}
                        </Column>}
                        {isDisabled() && <span className='popup-right__order_nohave'>{`У вас не хватает ${totalSum - coins} Ali Coins для покупки`}</span>}
                        <button
                            className='popup-right__order'
                            disabled={isDisabled() || selectedItems.length === 0}
                            onClick={onOrder}
                        >
                            <img className='popup-right__order_union' src={UnionW} alt='union' />
                            {coins}
                            <span className='popup-right__order_text'>Оформить заказ</span>
                        </button>
                    </Column>
                </Row>,
                document.body
            )}
        </>
    );
}

export default RightPopup
