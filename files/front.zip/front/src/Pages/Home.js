import './Home.scss';
import Column from '../Components/common/Column';
import Dashboard from '../Components/Dashboard/Dashboard';
import FunExpress from '../Components/FunExpress/FunExpress';
import Header from '../Components/Header/Header';
import Results from '../Components/Results/Results';


const Home = () => {
  return (
    <div className="app">
      <Column align='center' className="app__wrapper">
        <Header />
        <FunExpress />
        <Dashboard />
        <Results />
      </Column>
    </div>
  );
}

export default Home;
