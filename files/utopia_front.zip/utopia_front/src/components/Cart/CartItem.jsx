import { useState } from 'react';
import './CartItem.scss'
import ItemImage from '@assets/img/item-image.png'
import Union from '@assets/img/cart-union.png'
import Row from '../common/Row';
import Column from '../common/Column';

const CartItem = ({ item, onRemove, onCheck }) => {
    const {name, isOnline, price} = item
    const [checked, setChecked] = useState(false)
    const onChange = () => {
        onCheck(item, !checked)
        setChecked(!checked)
    }
    return (
        <Row className='item'>
            <input type='checkbox' checked={checked} onChange={onChange} className='item__checkbox' />
            <img className='item__image' src={ItemImage} alt='itemImage'/>
            <Column className='item__info' justyfy='space-between' align='flex-start'>
                <Column align='flex-start'>
                    <span className='item__name'>{name}</span>
                    {isOnline && <span className='item__online'>Только онлайн</span>}
                </Column>
                <Row>
                    <img className='item__coin' src={Union} alt='itemImage'/>
                    <span className='item__price'>{price}</span>
                </Row>
            </Column>
            <button className='item__trash' onClick={onRemove} />
        </Row>
    );
}

export default CartItem
