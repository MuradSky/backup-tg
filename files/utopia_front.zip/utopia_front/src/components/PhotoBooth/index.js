export { default } from './PhotoBooth';
