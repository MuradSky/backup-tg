export { default } from './Fortune';
