import { useEffect, useState } from 'react';

import styled from 'styled-components';

const ErrorStyled = styled.div`

`

function ErrorBoundary({ children }) {
    const [hasError, setHasError] = useState(false);
    
    useEffect(() => {
        const errorHandler = (error, errorInfo) => {
            // Handle errors here
            console.error('Error caught by Error Boundary:', error, errorInfo);
            window.location.href = '/';
            setHasError(true);
        };
    
        // Assign the error handler
        window.addEventListener('error', errorHandler);
    
        // Cleanup function
        return () => {
            window.removeEventListener('error', errorHandler);
        };
    }, []);
  
    if (hasError) {
      // Render fallback UI when an error occurs
        return <ErrorStyled>Something went wrong.</ErrorStyled>;
    }
    // Render children components as usual
    return children;
}
  
export default ErrorBoundary;
