import { memo } from 'react';
import classNames from 'classnames';

import Title from '@components/common/Title';
import Button from '@components/common/Button';

import Loock from '@assets/svg/lock.svg?react';
import styles from './BringAFriend.module.scss';

const weeks = [
    { id: 1, title: 'Отправляй промокод сегодня - становись лидером завтра!' },
    { id: 2, title: 'Мы подсчитываем результаты! Итоги объявим уже 21.11 - не пропусти!' },
    { id: 3, title: 'Церемония награждения уже сегодня! Присоединяйся к трансляции, чтобы узнать, кто стал победителем' },
];

const SoonBanner = ({ index }) => {
    const content = weeks[index];
    return (
        <div className={classNames(styles.soon, styles['soon_'+index])}>
            <Title cssClass={styles.soon_title}>{ content.title }</Title>
            {index === 0 ?
                <div className={styles.soon_lock}>
                    <Loock />
                    <span>Завтра здесь появится ТОП-5 лидеров гонки</span>
                </div> : index === 2 ?
                <div className={styles.soon_btn}>
                    <a href="https://n.dingtalk.com/dingding/live-room/index.html?roomId=Ui0oPkXsQ6iiMGQh" target="_blank" rel="noopener noreferrer">
                        <Button>
                            Подключиться
                        </Button>
                    </a>
                </div> : null
            }
        </div>
    );
};

export default memo(SoonBanner);