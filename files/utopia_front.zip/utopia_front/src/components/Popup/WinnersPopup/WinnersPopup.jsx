import { memo } from "react";

import Title from '../../common/Title';
import ScrollBar from "../ScrollBar/ScrollBar";

import Star from '@assets/svg/star.svg?react';
import styles from './WinnersPopup.module.scss';

const WinnersPopup = ({ data }) => {
    return (
        <div className={styles.block}>
            <Title cssClass={styles.title}>
                Рейтинг
            </Title>

           
            <div className={styles.table}>
                <div className={styles.table_head}>
                    <span>Имя Фамилия</span>
                    {/* <span>Заказы</span> */}
                </div>

                <ScrollBar cssClass={styles.scroll}>
                    <div className={styles.table_list}>
                        {data?.map((item, i) => (
                            <div className={styles.table_item} key={item.id}>
                                <span>
                                    {i+1}
                                    <i>
                                        {(i < 5) && <Star />}
                                    </i>
                                    {item.fio}
                                </span>
                                {/* <span>{item.position}</span> */}
                            </div>
                        ))}
                    </div>    
                </ScrollBar>
            </div>
        </div>
    )
}

export default memo(WinnersPopup);