import './RandomizerWinPopup.scss'
import Column from '../../common/Column';

const RandomizerWinPopup = () => {
    const gift = 500
    return (
        <>
            <Column align='flex-start' className='randomize-win__top'>
                <span className='randomize-win__title'>Ура, удача!</span>
                <span className='randomize-win__article'>{`Твой выигрыш — ${gift} Ali Coin!`}</span>
                <button className='randomize-win__gift'>+{gift}</button>
            </Column>
            
            <button
                className='randomize-win__take'
            >
                Забрать выигрыш
            </button>
        </>
    );
}

export default RandomizerWinPopup
