import { memo } from "react";
import { useDispatch } from "react-redux";

import Button from "@components/common/Button";
import { setCompleteTest, setOpenTest, setTestStart, setOpenErrorTest } from "@store/features";
import './TestPopup.scss'


const ErrorTest = () => {
    const dispatch = useDispatch();

    const closeTest = () => {
        dispatch(setOpenErrorTest(false));
        dispatch(setCompleteTest({ isCompleteTest: false }));
        dispatch(setOpenTest({ isOpenTest: false, testType: null }));
        dispatch(setTestStart({ isTestStart: false }));
    }

    return (
        <div className="CompleteTest">
            <div className="CompleteTest-title">
                Извените, данный тест не доступен
            </div>
            <Button variant="red" cssClass="CompleteTest-continue" onClick={closeTest}>
                Хорошо
            </Button>
        </div>
    );
};

export default memo(ErrorTest);