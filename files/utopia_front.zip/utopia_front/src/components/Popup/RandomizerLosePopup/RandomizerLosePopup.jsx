import './RandomizerLosePopup.scss'
import Column from '../../common/Column';

const RandomizerLosePopup = () => {
    
    return (
        <>
            <Column align='flex-start' className='randomize-lose__top'>
                <span className='randomize-lose__title'>Ничего страшного...</span>
                <span className='randomize-lose__article'>Тебе еще повезет!</span>
            </Column>
            
            <button
                className='randomize-lose__home'
            >
                На главную
            </button>
        </>
    );
}

export default RandomizerLosePopup
