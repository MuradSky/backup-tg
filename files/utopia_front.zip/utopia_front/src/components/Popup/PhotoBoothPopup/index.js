export { default } from './PhotoBoothPopup';
