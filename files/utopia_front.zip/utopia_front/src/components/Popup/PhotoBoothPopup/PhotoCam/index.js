export { default } from './PhotoCam';
