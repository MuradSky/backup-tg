import { memo, useState } from 'react';
import { useSelector } from 'react-redux';
import classNames from 'classnames';

import Button from '@components/common/Button';

import { useTogglePopup } from '@hooks';

import Arrow from '@assets/svg/arrow-circle.svg?react';
import Percent from '@assets/svg/percent.svg?react';
import Arrow2 from '@assets/svg/arrow.svg?react';
import Checked from '@assets/svg/checked.svg?react';
import styles from './Promocode.module.scss';
import doc3 from '@assets/docs/promo_conditions.pdf';


const fragmet = (code) => `Смотри, что у меня есть! Делюсь своим уникальным промокодом на скидку 500 руб. при заказе от 2 тысяч на AliExpress.
Промокод активен только с 11 по 18 ноября, — успевай сделать свой заказ ещё более выгодным 😉

Вводи мой промокод ALIFRIENDS${code} при оплате заказа, воспользоваться можно только 1 раз!  👉 https://aliexpress.ru`;

const Promocode = () => {
    const user = useSelector(state => state.user);
    const { toggle, onEnter, onLeave, onToggle } = useTogglePopup(user.isLogin);
    const [copied, setCopied] = useState(false);

    const copyToClipboard = async () => {
        if (copied) return;
        try {
            await navigator.clipboard.writeText(fragmet(user.profile.promocode));
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (err) {
            console.error('Failed to copy: ', err);
        }
    };
    return (
        <div 
            className={styles.wrapper}
            onMouseEnter={onEnter}
            onMouseLeave={onLeave}    
        >
            <button
                onClick={onToggle}
                className={classNames(styles.btn, toggle && styles.is_active)}
            >
                <span>ПРОМОКОД</span>
                <Arrow className={styles.arrow} />
                <Percent className={styles.percent} />
            </button>

            {toggle && 
                <div className={styles.data}>
                    <strong className={styles.data_title}>
                        Промокод
                    </strong>
                    <span className={styles.data_desc}>
                        Отправляй свой промокод друзьям и близким, чтобы выиграть один из пяти главных призов! 
                        Промокод активен только в период распродажи 11-11 и даёт скидку в 500 рублей от 2 тысяч в заказе
                    </span>

                    <div className={styles.data_code}>
                        ALIFRIENDS{user.profile.promocode}
                    </div>
                    <Button cssClass={classNames(styles.data_btn, copied && styles.is_active)} onClick={copyToClipboard}>
                        {copied ? 
                            <><Checked /> Промокод скопирован</> : 
                            'Скопировать промокод'
                        }
                    </Button>

                    <div className={styles.data_link}>
                        <a href={doc3} target="_blank" rel="noopener noreferrer">
                            Условия акции <Arrow2 />
                        </a>
                    </div>
                </div>
            }
        </div>
    );
};

export default memo(Promocode);