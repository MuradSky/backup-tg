import './game-bg.scss'

export function GameBg() {
	return (
		<div className="game-bg"></div>
	)
}
