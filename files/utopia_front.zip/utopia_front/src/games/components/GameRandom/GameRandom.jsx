import { useEffect, useRef, useState } from 'react'
import { GameBg } from '..'
import { random, weightedRandom } from '../../utils/random'
import { GameRandomCard } from './GameRandomCard'
import RandomizerComboImage from '../../assets/randomizer-combo.svg'
import IconScore from '../../assets/icon-score.svg'
import './game-random.scss'
import { shuffle } from 'gsap/all'


const SLOTS = [
  { value: 200, label: 'fire' },
  { value: 100, label: 'gamepad' },
  { value: 200, label: 'horse' },
  { value: 500, label: 'sparkle' },
  { value: 100, label: 'cat' },
  { value: 500, label: 'bag' },
]

const COMBOS = [
  { values: [0,0,0], value: 2000, weight: 2 },
  { values: [500, 500, 500], weight: 3 },
  { values: [200, 500, 500], weight: 5 },
  { values: [100, 500, 500], weight: 5 },
  { values: [200, 200, 500], weight: 5 },
  { values: [100, 200, 500], weight: 10 },
  { values: [200, 200, 200], weight: 10 },
  { values: [100, 200, 200], weight: 10 },
  { values: [100, 200, 200], weight: 20 },
  { values: [100, 100, 200], weight: 20 },
  { values: [100, 100, 100], weight: 10 },
]

const runSlots = () => {
  const combo = weightedRandom(COMBOS)

  if (combo.value) {
    const index = Math.floor(Math.random() * SLOTS.length)
    return {
      slots: Array.from({ length: 3 }, () => index),
      score: combo.value,
      supercombo: true
    }
  }

  let score = 0
  const tor = [];
  
  (combo.values)
    .forEach((value, i) => {
      const slots = SLOTS.reduce((acc, slot, i) => 
        slot.value === value
          ? [...acc, i]
          : acc, []
      )
      // Make sure it's not a supercombo
      const index = i === combo.values.length - 1
      ? slots[tor.includes(slots[0]) ? 1 : 0]
        : random(slots)
      score += SLOTS[index].value

      tor.push(index)
  })
  return {
    slots: shuffle(tor),
    score,
    supercombo: false
  }
}

export function GameRandom({ onScore }) {
  const [results, setResults] = useState([0, 0, 0])
  const [ready, setReady] = useState(false)
  const DELAY = 0.5
  const [score, setScore] = useState(0)
  const isSuperCombo = useRef(false)
  
  const comboRef = useRef(null)
  const scoreRef = useRef(null)

  useEffect(() => {
    const { slots, score, supercombo } = runSlots();
    isSuperCombo.current = supercombo;
    setResults(slots)
    setScore(score)
    setReady(true)
  }, [])

  useEffect(() => {
    if (score > 0) onScore(score);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [score]);

  const onComplete = () => {
    scoreRef.current?.classList.add('game-randomizer__score_show')
    if (isSuperCombo.current)
      comboRef.current?.classList.add('game-randomizer__supercombo_show')
  }

  return (
    <>
      <div className="game-randomizer">
        <GameBg />
        
        <img
          src={RandomizerComboImage}
          ref={comboRef}
          className="game-randomizer__supercombo"
        />

        <div className="game-randomizer__field">
          <div
            className="game-randomizer__score"
            ref={scoreRef}
          >
            +{score} <img src={IconScore} />
          </div>

          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 569 386"><rect width="500" height="21" x="10" y="365" fill="#FFA0FF" rx="4"/><rect width="520" height="300" y="65" fill="#FFE500" rx="10"/><rect width="13.236" height="38.6049" x="519.5" y="272" fill="#FFFF74" rx="6"/><path fill="#FFE500" d="M539 162.7h18.8v112.5H539z"/><rect width="40" height="54" x="528.3" y="264" fill="#FFFF74" rx="6"/><circle cx="547.854" cy="153.909" r="19.8539" fill="#FFFF74"/>
            <mask id="a" width="446" height="118" x="37" y="15.2" fill="#000" maskUnits="userSpaceOnUse"><path fill="#fff" d="M37 15.2h446v118H37z" /><path fillRule="evenodd" d="M338 47h127a10 10 0 0 1 10 10v58a10 10 0 0 1-10 10H55a10 10 0 0 1-10-10V57a10 10 0 0 1 10-10h123c23-15 50.5-23.8 80-23.8s57 8.7 80 23.8Z" clipRule="evenodd" /></mask><path fill="#FFFF74" fillRule="evenodd" d="M338 47h127a10 10 0 0 1 10 10v58a10 10 0 0 1-10 10H55a10 10 0 0 1-10-10V57a10 10 0 0 1 10-10h123c23-15 50.5-23.8 80-23.8s57 8.7 80 23.8Z" clipRule="evenodd" /><path fill="#FFA0FF" d="m338 47-4.4 6.7 2 1.3h2.4v-8Zm-160 0v8h2.4l2-1.3L178 47Zm160 8h127V39H338v16Zm127 0a2 2 0 0 1 2 2h16c0-10-8-18-18-18v16Zm2 2v58h16V57h-16Zm0 58a2 2 0 0 1-2 2v16c10 0 18-8 18-18h-16Zm-2 2H55v16h410v-16Zm-410 0a2 2 0 0 1-2-2H37c0 10 8 18 18 18v-16Zm-2-2V57H37v58h16Zm0-58c0-1.1.9-2 2-2V39c-10 0-18 8-18 18h16Zm2-2h123V39H55v16Zm127.4-1.3A137.3 137.3 0 0 1 258 31.2v-16c-31.1 0-60.1 9.2-84.3 25.1l8.7 13.4ZM258 31.2c28 0 53.9 8.2 75.6 22.5l8.7-13.4A153.3 153.3 0 0 0 258 15.2v16Z" mask="url(#a)" /><path fill="#F684F6" d="M198.4 104c-.9.4-1.8.4-2.7 0-.9-.4-1.6-1-2.1-2L181.9 78c-1.3-2.5-.7-4.3 1.6-5.4l8.1-4c1-.5 2-.7 2.9-.5.8.2 1.5.7 1.9 1.6.4.8.4 1.6 0 2.4-.3.8-1 1.5-2 2l-5.6 2.7 3.2 6.4 6.3-3.2c.8-.4 1.5-.4 2.2-.2.7.3 1.2.7 1.5 1.3.3.5.3 1.1 0 1.8-.2.7-.7 1.2-1.4 1.6l-6.4 3.1 5.5 11.2c.5 1 .6 2 .4 3a3 3 0 0 1-1.7 2ZM220.1 95.2c-3 1-5.6.9-7.8-.3a9.8 9.8 0 0 1-4.7-6L203 74.6c-1-3-.9-5.6.2-8 1-2.3 3.1-4 6.1-5 3-.9 5.7-.7 8 .6 2.2 1.3 3.8 3.4 4.7 6.3l4.5 14.2c1 2.8.8 5.4-.3 7.6a9.8 9.8 0 0 1-6.2 4.8Zm-2-6c1-.3 1.6-.8 2-1.5a3 3 0 0 0 .1-2.6l-5-15.7c-.3-1-.9-1.7-1.6-2.1a3 3 0 0 0-2.5-.2c-.8.2-1.5.8-1.9 1.6-.4.7-.4 1.6 0 2.6l5 15.7c.2 1 .8 1.7 1.5 2 .8.4 1.6.4 2.5.2ZM234 91.5c-1 .2-1.8-.1-2.5-.8a5 5 0 0 1-1.3-3l-3.7-25.9c-.1-1.3 0-2.4.7-3.3.7-1 1.7-1.5 3.2-1.7l4.2-.5c2.4-.4 4.6-.2 6.4.5a9 9 0 0 1 4.3 3.2c1 1.4 1.7 3.1 2 5 .3 2 0 3.9-.7 5.6-.8 1.7-2 3-3.7 4l7.1 8.7c.8 1 1.3 1.8 1.4 2.7.1 1-.1 1.7-.7 2.4-.6.6-1.3 1-2.1 1-1.3.3-2.6-.4-3.7-1.9l-7.1-9.2-2-3.6h-.6l1.7 12.1c.2 1.2 0 2.3-.5 3.2a3 3 0 0 1-2.3 1.5Zm1.1-20c2-.3 3.5-1 4.4-2 1-1 1.4-2.3 1.2-3.8a4.4 4.4 0 0 0-2-3.2c-1-.8-2.4-1-4-.8l-1.3.2 1.4 9.6h.3ZM261.1 89.4a3 3 0 0 1-2.4-1.2c-.6-.7-1-1.7-.9-2.9l.5-25.4-4.1-.1c-.8 0-1.5-.3-2-.8-.6-.6-.8-1.3-.8-2 0-.8.3-1.4.8-1.9a3 3 0 0 1 2-.7l15.1.3a3 3 0 0 1 2 .8c.6.5.9 1.1.9 1.9 0 .8-.3 1.4-1 2-.5.5-1.2.7-2 .7h-4l-.6 25.4c0 1.1-.4 2-1 2.8a3 3 0 0 1-2.5 1ZM280.8 91.3a10 10 0 0 1-6.6-3.8c-1.5-2.1-2-4.6-1.5-7.5l3.8-21.2c.1-1 .6-1.8 1.3-2.3a3 3 0 0 1 2.4-.7c1 .2 1.6.7 2 1.4.5.8.7 1.7.5 2.7l-3.5 20c-.3 1.2-.1 2.2.4 2.9.4.7 1.2 1.1 2.1 1.3a3 3 0 0 0 2.4-.6c.7-.5 1.2-1.3 1.4-2.5l3.5-19.8c.2-1 .7-1.9 1.4-2.4.8-.7 1.7-.9 2.7-.7 1 .2 1.8.7 2.4 1.5.6.9.8 1.8.6 2.8l-3.7 21c-.5 3-1.8 5.2-4 6.6a9.9 9.9 0 0 1-7.6 1.3ZM296 94.8c-1-.3-1.5-1-2-1.8a4 4 0 0 1 .1-3l8.8-24.5a5.7 5.7 0 0 1 2.4-3c1-.7 2.4-.8 3.8-.3 1.3.5 2.2 1.3 2.7 2.4.5 1.1.7 2.6.6 4.6l-.9 15.6.6.2 1.4-6.6 3.4-9.4c.4-1 1-1.8 1.8-2.2.9-.4 1.8-.5 2.6-.2a3 3 0 0 1 1.8 1.8c.4.8.4 1.8 0 2.8l-9.4 26c-.4 1.1-1 1.9-1.8 2.3-.8.4-1.7.4-2.7 0-.9-.3-1.6-1-2-1.9a14 14 0 0 1-.3-4.4l.5-20.4-.6-.2-1.4 5.5-5 14.2c-.5 1-1 1.8-2 2.3a3 3 0 0 1-2.5.2ZM317.3 103.2c-1-.5-1.6-1.2-1.8-2.2a4 4 0 0 1 .5-3l13-23.7c.6-.9 1.3-1.5 2.2-1.7.9-.3 1.8-.2 2.8.3l8.4 4.6c1 .6 1.7 1.2 2 2 .3.6.3 1.3 0 2-1 1.5-2.4 1.6-4.4.5l-5.7-3.1-4 7.4 5.8 3.2c.8.5 1.3 1 1.5 1.7a2.4 2.4 0 0 1-1.8 3.2c-.7.2-1.4.1-2.2-.3l-5.9-3.2-4.6 8.3 6.1 3.4c.9.4 1.4 1.1 1.7 2 .4.8.3 1.6-.1 2.4-.5.9-1.2 1.4-2 1.6-.9.1-1.7 0-2.6-.5l-8.9-4.9ZM86 67.3c-.2-.7-.8-1.3-1.5-1.3s-1.3.6-1.4 1.3A19 19 0 0 1 66.3 84c-.7 0-1.3.7-1.3 1.4 0 .8.6 1.4 1.3 1.5 9 1 15.7 7.9 16.8 16.9 0 .7.7 1.3 1.4 1.3s1.3-.6 1.4-1.3a19 19 0 0 1 16.9-17c.7 0 1.2-.6 1.2-1.3 0-.7-.5-1.3-1.2-1.3a19.3 19.3 0 0 1-16.9-16.8ZM442 67.3c-.1-.7-.8-1.3-1.5-1.3s-1.3.6-1.4 1.3A19 19 0 0 1 422.3 84c-.7 0-1.3.7-1.3 1.4 0 .8.6 1.4 1.3 1.5 9 1 15.7 7.9 16.8 16.9 0 .7.7 1.3 1.4 1.3s1.3-.6 1.4-1.3a19 19 0 0 1 16.9-17c.6 0 1.2-.6 1.2-1.3 0-.7-.5-1.3-1.2-1.3a19.3 19.3 0 0 1-16.9-16.8Z" /></svg>

          {ready && results.map((resultIndex, i) =>
            <GameRandomCard
              key={i}
              delay={DELAY * i}
              resultIndex={resultIndex}
              className={`game-randomizer__card game-randomizer__card_${i + 1}`}
              onComplete={i === results.length - 1 ? onComplete : undefined}
            />
          )}
        </div>
      </div>
    </>
  )
}
