import { Btn } from '..'
import RandomizerTry from '../../assets/randomizer-try.svg'
import RandomizerIntro from '../../assets/randomizer-intro.svg'
import './game-random-intro.scss'

export function GameRandomIntro({
  disabled,
  onStart = () => {}
}) {

  return (
    <>
      <div className="randomizer-intro">
        <div className="randomizer-intro__title">Рычаг фортуны</div>
        <Btn
          yellow
          disabled={disabled}
          className="randomizer-intro__start"
          onClick={() => onStart()}
        >
          {disabled ? 'Не осталось попыток' : 'Испытать удачу'}
        </Btn>
        <div className="randomizer-intro__content">
          <div className="randomizer-intro__info">
            <div className="randomizer-intro__desc">Испытай свою удачу! Ежедневно крути рандомайзер, чтобы заработать дополнительные Ali Coin. Готов проверить, что достанется тебе сегодня?</div>
            <img className="randomizer-intro__try" src={RandomizerTry} />
          </div>
          <img className="randomizer-intro__cover" src={RandomizerIntro} />
        </div>
      </div>
    </>
  )
}
