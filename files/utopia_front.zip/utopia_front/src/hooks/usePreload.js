import { useMounted } from './useMounted';

export const usePreload = (data) => {
    useMounted(() => {
        if (data && Array.isArray(data)) {
            data.forEach(item => {
                const link = document.createElement('link');
                link.setAttribute('as', item.as);
                link.setAttribute('href', item.href);

                document.head.appendChild(link);
            });
        }
    });
};