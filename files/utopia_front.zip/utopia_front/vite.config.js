import { fileURLToPath } from 'node:url';
import fs from 'fs';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import svgr from 'vite-plugin-svgr';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function mediapipe_workaround() {
  return {
    name: 'mediapipe_workaround',
    load(id) {
      	if (path.basename(id) === 'selfie_segmentation.js') {
        	let code = fs.readFileSync(id, 'utf-8');
    		code += 'exports.SelfieSegmentation = SelfieSegmentation;';
		  	return { code };
      	} else {
        	return null;
      	}
    },
  };
}

export default defineConfig({
	plugins: [react(), svgr()],
	server: {
		port: 3000,
		// proxy: {
		// 	'/': {
		// 		target: 'https://aliverse.blacksun.tech', // Укажите целевой сервер
		// 		changeOrigin: true, // Меняет заголовок Host на целевой сервер
		// 		rewrite: (path) => path.replace(/^\/api/, ''), // Убирает префикс /api, если нужно
		// 	},
		// },
	},
	css: {
		preprocessorOptions: {
			scss: {
				silenceDeprecations: ['legacy-js-api']
			}
		}
	},
	build: {
		sourcemap: true,
		rollupOptions: {
			plugins: [
				mediapipe_workaround(),
			]
		}
	},
	resolve: {
		alias: {
			'@components': path.resolve(__dirname, './src/components'),
			'@utils': path.resolve(__dirname, './src/utils'),
			'@assets': path.resolve(__dirname, './src/assets'),
			'@hooks': path.resolve(__dirname, './src/hooks'),
			'@store': path.resolve(__dirname, './src/store'),
			'@config': path.resolve(__dirname, './src/config'),
		},
	},
});
