#!/bin/bash

COMPONENT_NAME=$1
COMPONENT_DIR=./src/Components/$COMPONENT_NAME

# Create component directory
mkdir -p $COMPONENT_DIR

# Create component file
cat <<EOL > $COMPONENT_DIR/$COMPONENT_NAME.jsx
import { memo } from 'react';
import Title from 'Components/common/Title';

import styles from './$COMPONENT_NAME.module.scss';

const $COMPONENT_NAME = () => {
    return (
        <div className={styles.block}>
            <Title cssClass={styles.title}></Title>
        </div>
    );
};

export default memo($COMPONENT_NAME);
EOL

# Create SCSS module file
touch $COMPONENT_DIR/$COMPONENT_NAME.module.scss

cat <<EOL > $COMPONENT_DIR/$COMPONENT_NAME.module.scss
.block {

}

.title {

}
EOL

# Create index file
cat <<EOL > $COMPONENT_DIR/index.js
export { default } from './$COMPONENT_NAME';
EOL

echo "Component $COMPONENT_NAME created successfully!"
