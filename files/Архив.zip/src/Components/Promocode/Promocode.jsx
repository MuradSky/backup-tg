import { memo, useState } from 'react';
import { useSelector } from 'react-redux';
import classNames from 'classnames';

import Button from 'Components/common/Button';

import { useTogglePopup } from 'hooks';

import { ReactComponent as Arrow } from 'assets/svg/arrow-circle.svg';
import { ReactComponent as Arrow2 } from 'assets/svg/arrow.svg';
import { ReactComponent as Checked } from 'assets/svg/checked.svg';
import styles from './Promocode.module.scss';

const Promocode = () => {
    const user = useSelector(state => state.user);
    const { toggle, onEnter, onLeave, onToggle } = useTogglePopup(user.isLogin);
    const [copied, setCopied] = useState(false);

    const copyToClipboard = async () => {
        try {
            await navigator.clipboard.writeText('ALIFRIENDSXXX');
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch (err) {
            console.error('Failed to copy: ', err);
        }
    };
    return (
        <div 
            className={styles.wrapper}
            onMouseEnter={onEnter}
            onMouseLeave={onLeave}    
        >
            <button onClick={onToggle} className={classNames(styles.btn, toggle && styles.is_active)}>
                ПРОМОКОД
                <Arrow />
            </button>

            {toggle && 
                <div className={styles.data}>
                    <strong className={styles.data_title}>
                        Промокод
                    </strong>
                    <span className={styles.data_desc}>
                        Отправляй свой промокод друзьям и близким, чтобы выиграть один из пяти главных призов! 
                        Промокод активен только в период распродажи 11-11 и даёт скидку в 500 рублей от 2 тысяч в заказе
                    </span>

                    <div className={styles.data_code}>
                        ALIFRIENDSXXX
                    </div>
                    <Button cssClass={classNames(styles.data_btn, copied && styles.is_active)} onClick={copyToClipboard}>
                        {copied ? 
                            <><Checked /> Промокод скопирован</> : 
                            'Скопировать промокод'
                        }
                    </Button>

                    <div className={styles.data_link}>
                        <a href="/" target="_blank" rel="noopener noreferrer">
                            Условия акции <Arrow2 />
                        </a>
                    </div>
                </div>
            }
        </div>
    );
};

export default memo(Promocode);