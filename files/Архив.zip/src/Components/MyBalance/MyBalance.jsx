import { memo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import classNames from 'classnames';


import Button from 'Components/common/Button';
import { setOpenSharedCoin } from 'store/features/modalsSlice';
import { useTogglePopup } from 'hooks';
import { priceFormatter } from 'utils';

import { ReactComponent as Btn  } from 'assets/svg/balance-btn.svg';
import { ReactComponent as Coin  } from 'assets/svg/coin.svg';
import styles from './MyBalance.module.scss';

const MyBalance = ({ cssClass }) => {
    const dispatch = useDispatch();
    const user = useSelector(state => state.user);
    const { toggle, onEnter, onLeave, onToggle } = useTogglePopup(user.isLogin);

    const openSharedCoin = ()=> {
        dispatch(setOpenSharedCoin({ isOpenSharedCoin: true }))
    }

    return (
        <div
            className={styles.wrapper}
            onMouseEnter={onEnter}
            onMouseLeave={onLeave}
        >
            <button 
                className={classNames(styles.btn, toggle && styles.is_active, cssClass)} 
                onClick={onToggle}
            >
                <Btn className={styles.btn_bg} />
                <span className={styles.btn_inner}>
                    <Coin />
                    МОЙ БАЛАНС
                </span>
            </button>

            {toggle &&
                <div className={styles.data}>
                    <strong className={styles.data_title}>Мой баланс</strong>
                    <div className={styles.data_coins}>
                        {priceFormatter(user.profile.bonuses || 0)}
                        <Coin />
                        <span>ALI COINS</span>
                    </div>
                    {!!user.profile.bonuses ?
                        <Button onClick={openSharedCoin}>Поделиться коинами</Button> :
                        null
                    }
                </div>
            }
        </div>
    );
};

export default memo(MyBalance);