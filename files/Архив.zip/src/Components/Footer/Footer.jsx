import { memo } from 'react';

import banner from 'assets/img/footer/banner.png';

import { ReactComponent as Btn1 } from 'assets/svg/soc-btn.svg';
import { ReactComponent as Btn2 } from 'assets/svg/soc-btn-1.svg';
import { ReactComponent as Logo } from 'assets/svg/logo.svg';

import styles from './Footer.module.scss';

const Footer = () => {
    return (
        <div className={styles.block}>
            <div className={styles.bg}>
                <picture>
                    <img src={banner} alt="" width={1440} height={485} />
                </picture>
            </div>

            <div className={styles.bottom}>
                <div className={styles.logo}>
                    <Logo />
                </div>
                <div className={styles.links}>
                    <a href="/" target="_blank" rel="noopener noreferrer">Пользовательское соглашение</a>
                    <a href="/" target="_blank" rel="noopener noreferrer">Политика конфиденциальности</a>
                    <a href="/" target="_blank" rel="noopener noreferrer">Условия акции</a>
                </div>

                <div className={styles.btns}>
                    <a href="/" target="_blank" rel="noopener noreferrer">
                        <Btn1 />
                    </a>
                    <a href="/" target="_blank" rel="noopener noreferrer">
                        <Btn2 />
                    </a>
                </div>
            </div>
        </div>
    );
};

export default memo(Footer);
