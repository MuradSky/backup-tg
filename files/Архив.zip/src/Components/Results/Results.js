import cn from 'classnames';
import Column from '../common/Column';
import Row from '../common/Row';

import './Results.scss';
import hint from '../../assets/img/results-hint.svg'
import smarphone from '../../assets/img/category-smartphone.svg'
import tech from '../../assets/img/category-tec.svg'
import shoes from '../../assets/img/category-shoes.svg'
import toys from '../../assets/img/category-toys.svg'
import clothes from '../../assets/img/category-clothes.svg'
import topSales from '../../assets/img/results-top.png'
import flag from '../../assets/img/flag.png'
import scale from '../../assets/img/range.png'
import { useState } from 'react';
import styled from 'styled-components';

const itemCards = [smarphone, tech, toys, clothes, shoes]

const StyledRange = styled.div`
  width: ${({ width }) => width};
  height: 100%;
  background: #FFE500;
  border-radius: 5px;
`

const TOP_CATEGORIES = 'topCategories'
const DAY_PRODUCT = 'dayProduct'

const DATE_START = Date.parse('11 Nov 2024 00:01:00 GMT+3');
const DATE_FINISH = Date.parse('17 Nov 2024 23:59:00 GMT+3');

function Results() {
  const [selectedChapter, setSelectedChapter] = useState(TOP_CATEGORIES)
  const getPercent = () => {
    const today = Date.now()
    if (today > DATE_FINISH) {
      return '100%'
    } else if (today < DATE_START) {
      return '0'
    }

    const range = DATE_FINISH - DATE_START
    const current = today - DATE_START
    const percent = current / range * 100

    return `${percent}%`
  }
  const categoriesClasses = cn(
    'results__select_btn',
    { selected: selectedChapter === TOP_CATEGORIES }
  )
  const productClasses = cn(
    'results__select_btn',
    { selected: selectedChapter === DAY_PRODUCT }
  )
  return (
    <Column className='results'>
        <Row className='results__title'>
            <span>Результаты 11.11</span>
            <div className='hint'>
              <img
                className='hint__text'
                src={hint}
                alt='hint'
              />
            </div>
        </Row>
        <Row className='results__select'>
            <button
              className={categoriesClasses}
              onClick={() => setSelectedChapter(TOP_CATEGORIES)}
            >
              Топ категорий
            </button>
            <button
              className={productClasses}
              onClick={() => setSelectedChapter(DAY_PRODUCT)}
            >
              Товар дня
            </button>
        </Row>
        <div className='results__items'>
          {selectedChapter === TOP_CATEGORIES && itemCards.map((src, i) => (
            <img className='categories__card' src={src} alt='item' key={i} />
          ))}

          {selectedChapter === DAY_PRODUCT && (
            <Row className='dayproduct' justyfy='center' align='flex-end'>
              <button className='dayproduct__btn'>Смотреть товар</button>
            </Row>
          )}

          <Column align='flex-start' justyfy='space-between' className='total__gmv'>
            <span className='total__title'>GMV</span>
            <span className='total__sum'>115 356 556 ₽</span>
          </Column>
          <Column align='flex-start' justyfy='space-between'  className='total__orders'>
            <span className='total__title'>Созданные заказы</span>
            <span className='total__sum'>120 000 455</span>
          </Column>
          <Column align='flex-start' justyfy='space-between'  className='total__aov'>
            <span className='total__title'>Созданные заказы</span>
            <span className='total__sum'>20 500 ₽</span>
          </Column>
          <img src={topSales} alt='top' className='results__top' />
        </div>
        <Column className='range'>
          <Row className='range__names' justyfy='space-between'>
            <span className='range__names_target'>СТАРТ</span>
            <span className='range__names_target'>ЦЕЛЬ<img className='range__names_flag' alt='flag' src={flag} /></span>
          </Row>
          <Row className='range__track' justyfy='flex-start'>
            <StyledRange width={getPercent()} />
          </Row>
          <img className='range__scale' alt='range' src={scale} />
        </Column>
    </Column>
  );
}

export default Results;
