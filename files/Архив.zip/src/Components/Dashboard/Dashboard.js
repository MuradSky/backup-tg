import Column from '../common/Column'
import Row from '../common/Row'

import './Dashboard.scss'
import footPlate from '../../assets/img/plate-foot.png'
import articlePlate from '../../assets/img/plate-article.png'

const Dashboard = () => {
    return (
        <Column className='dashboard'>
            <>
                <Row className='dashboard__title' justyfy='center'>Погнали распродажить!</Row>
                <Row className='dashboard__content'>
                    <div className='banner__foot'>
                        <img src={footPlate} className='banner__foot_plate' alt='foot' />
                    </div>
                    <div className='banner__article'>
                        В этом году
                        <span className='banner__article_eveven'> 11.11</span> пройдёт для нас в
                        <span className='banner__article_eveven'> 11</span>-ый раз, –<br/>
                        магия чисел, не иначе! А у нас, как и всегда,<br/>
                        грандиозные планы и цели на эту распродажу!<br/>
                        <br/>
                        Отслеживать успехи и следить за нашими<br/>
                        показателями можно в этом дашборде. Аналитику<br/>
                        за предыдущий день обновляем ежедневно<br/>
                        в 11:11 — не пропускай!
                        <img src={articlePlate} className='banner__article_plate' alt='article' />
                    </div>
                </Row>
            </>
        </Column>
    )
}

export default Dashboard
