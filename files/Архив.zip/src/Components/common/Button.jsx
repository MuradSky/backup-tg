import { memo } from "react"
import styled from "styled-components"
import Loader from "./Loader";

const StyledButton = styled.button`
    position: relative; 
    font-family: 'Inter', sans-serif;
    font-size: 18px;
    font-weight: 500;
    line-height: 21.6px;
    text-align: center;
    color: ${({ $variant }) => (
        !$variant ? 'var(--c-black)' : 
            $variant === 'blue' ? '#fff' :
            $variant === 'red' ? '#fff' :
            ''
    )};
    background-color: ${({ $variant }) => (
        !$variant ? 'var(--c-yellow)' :
        $variant === 'blue' ? '#00C0FF' :
        $variant === 'red' ? '#FF5F5B' :
        '' 
    )};
    cursor: pointer;
    padding: 22px 32px;
    border-radius: 10px;
    border: 0;
    transition: background-color .3s linear;

    &:disabled {
        opacity: .6;
        pointer-events: none;
    }

    &:hover:not(:active):not([disabled]) {
        background-color: ${({ $variant }) => (
            !$variant ? 'var(--c-yellow-h)' :
            $variant === 'blue' ? '#0193c4' : 
            $variant === 'red' ? '#e42c28' : 
            ''
        )};
    }

    .btn-loader {
        position: absolute;
        top: 50%;
        left: 50%;
        z-index: 10;
        transform: translate(-50%, -50%);
        zoom: .6;
        color: #000;
    }
`
const Button = ({ 
    children, 
    cssClass, 
    disabled,
    onClick,
    variant,
    isLoading,
}) => {
    return (
        <StyledButton 
            onClick={onClick}
            $variant={variant} 
            className={cssClass}
            disabled={disabled}
        >
            {isLoading && <Loader cssClass="btn-loader" />}
            <span style={{ opacity: isLoading ? 0 : 1 }}>{children}</span>
        </StyledButton>
    )
}

export default memo(Button);