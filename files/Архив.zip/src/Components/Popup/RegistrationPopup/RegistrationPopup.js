import './RegistrationPopup.scss'
import Row from '../../common/Row';
import { useDispatch } from 'react-redux';
import { setOpenAuth } from '../../../store/features/modalsSlice';

const RegistrationPopup = () => {
    const dispatch = useDispatch();

    const handleRegister = ()=> {
        dispatch(setOpenAuth({
            isOpenAuth: true,
            stage: 'register',
        }));
    }

    const handleLogin = ()=> {
        dispatch(setOpenAuth({
            isOpenAuth: true,
            stage: 'login',
        }));
    }


    return (
        <>
            <span className='registration__title'>Привет!</span>
            <span className='registration__article'>
                Добро пожаловать в торгово-увлекательный<br/>
                парк Fun Express! Заполни форму<br/>
                регистрации, чтобы получить свой билет<br/>
                в мир приключений и ярких эмоций!<br/>
            </span>
            <Row className='registration__signin'>
                <button className='registration__signin_btn' onClick={handleRegister}>
                    Зарегистрироваться
                </button>
            </Row>
            <Row className='registration__login'>
                <button className='registration__login_btn' onClick={handleLogin} />
            </Row>
        </>
);
}

export default RegistrationPopup
