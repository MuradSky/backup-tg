import './PromocodePopup.scss'
import Column from '../../common/Column';

const PromocodePopup = () => {
    const promocode = 'ALITEAM001'
    const promocodeTemplate = `Привет! Делюсь секретным промокодом
на скидку 500 рублей! Действует только в 
период распродажи 11-11 на AliExpress ❤️\n
Мой промокод: `
    return (
        <>
            <Column align='flex-start' className='promocode__top'>
                <span className='promocode__title'>Приводи друзей -<br/>получай подарки!</span>
                <span className='promocode__article'>
                Хочешь отправиться в путешествие или получить новый<br/>
                смартфон? Приводи друзей на AliExpress! С 11 по 17 ноября<br/>
                делись своим уникальным промокодом со всеми, –<br/>
                чем больше применений, тем выше шанс выиграть один<br/>
                из пяти главных призов!
                </span>
            </Column>
            
            <Column align='flex-start' className='promocode__bottom'>
                <span className='promocode__yours'>
                    Твой промокод - ALITEAM001
                </span>
                <button
                    className='promocode__share'
                    onClick={() => {navigator.clipboard.writeText(promocodeTemplate + promocode)}}
                >
                    Поделиться промокодом
                </button>
            </Column>
        </>
    );
}

export default PromocodePopup
