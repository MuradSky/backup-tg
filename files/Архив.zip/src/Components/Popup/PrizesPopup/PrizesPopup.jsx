import { memo } from "react"

import Title from '../../common/Title';
import ScrollBar from "../ScrollBar/ScrollBar";
import './PrizesPopup.scss'

import place1 from '../../../assets/img/place/1.png';
import place2 from '../../../assets/img/place/2.png';
import place3 from '../../../assets/img/place/3.png';
import place4 from '../../../assets/img/place/4.png';
import place5 from '../../../assets/img/place/5.png';

const prizes = [
    place1, place2, place3, place4, place5
]

const PrizesPopup = () => {
    return (
        <div className="PrizesPopup">
            <Title cssClass="PrizesPopup-title">
                Призы
            </Title>

            <ScrollBar>
                <div className="PrizesPopup-list">
                    {prizes.map((item, i)=> (
                        <div className="PrizesPopup-img" key={i}>
                             <picture>
                                <img src={item} alt="" width={310}  height={130} />
                            </picture>
                        </div>
                    ))}
                </div>
            </ScrollBar>
        </div>
    )
}

export default memo(PrizesPopup);