import { memo } from "react";

import Title from '../../common/Title';
import ScrollBar from "../ScrollBar/ScrollBar";

import { ReactComponent as Star } from '../../../assets/svg/star.svg';

import './WinnersPopup.scss';

const winners = [
    { id: 1, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: true },
    { id: 2, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: true },
    { id: 3, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: true },
    { id: 4, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: true },
    { id: 5, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 6, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 7, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 8, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 9, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 10, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 12, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 13, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 14, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 15, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 16, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 17, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 18, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 19, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
    { id: 20, orders: 1934602, email: 'dimapup@gmail.com', fullName: 'Иван Иванов', isTop: false },
]

const WinnersPopup = () => {
    return (
        <div className="WinnersPopup">
            <Title cssClass="WinnersPopup-title">
                Рейтинг
            </Title>

           
            <div className="WinnersPopup-table">
                <div className="WinnersPopup-table-head">
                    <span>Имя Фамилия</span>
                    <span>Почта</span>
                    <span>Заказы</span>
                </div>

                <ScrollBar cssClass="WinnersPopup-scroll">
                    <div className="WinnersPopup-table-list">
                        {winners.map(item => (
                            <div className="WinnersPopup-table-item" key={item.id}>
                                <span>
                                    {item.id}
                                    <i>
                                        {item.isTop && <Star />}
                                    </i>
                                    {item.fullName}
                                </span>
                                <span>{item.email}</span>
                                <span>{item.orders}</span>
                            </div>
                        ))}
                    </div>    
                </ScrollBar>
            </div>
        </div>
    )
}

export default memo(WinnersPopup);