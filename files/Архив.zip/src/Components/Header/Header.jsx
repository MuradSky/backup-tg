import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';

import MyBalance from 'Components/MyBalance';
import Promocode from 'Components/Promocode';
import Basket from 'Components/Basket';
import Loader from 'Components/common/Loader';
import Row from 'Components/common/Row';
import Popup from 'Components/Popup/Popup';
import RegistrationPopup from 'Components/Popup/RegistrationPopup/RegistrationPopup';

import { setUserDestroy } from 'store/features/userSlice';
import { setDestroyProduct } from 'store/features/productsSlice';
import { useLocalStorage } from 'hooks';
import { getApiRoute } from 'config/routes';

import Logo from 'assets/img/logo.svg';
import { ReactComponent as User } from 'assets/svg/user.svg';
import { ReactComponent as Arrow } from 'assets/svg/arrow.svg';

import './Header.scss';

const loader = (
    <div className="Header-loader">
        <Loader />
    </div>
)

const Header = () => {
    const [isLoading, setIsLoading] = useState(false);
    const user = useSelector(state => state.user);
    const { hardRemove: removeToken } = useLocalStorage('_ali_access_token');
    const { hardRemove: removeBasket } = useLocalStorage('_ali_basket');

    const dispatch = useDispatch(); 
    const logOut = async () => {
        if (isLoading) return;
        setIsLoading(true);
        try {
            await axios.get(getApiRoute('auth.logout'), {
                headers: {
                    Authorization: 'Bearer '+user?.accessToken
                }
            })
            dispatch(setUserDestroy())
            dispatch(setDestroyProduct())
            removeToken();
            removeBasket();
        } catch (err) {
            console.log(err)
        } finally {
            setIsLoading(false);
        }
    }

    if (user.isLogin) {
        return (
            <Row className='header'>
                <Row className='header__left' justyfy='flex-start'>
                    <MyBalance />
                    <Basket />
                </Row>
                <img alt='logo' className='header__logo' src={Logo} />
                <Row className='header__right' justyfy='flex-end'>
                    <Promocode />
                    <div className='Header-user'>
                        <button className='account'>
                            <User />
                        </button>
                        <div className='Header-user-profile'>
                            {isLoading && loader}
                            <strong>{user.profile?.name} {user.profile?.surname}</strong>
                            <span>{user.profile?.email}</span>
                            <div className="Header-user-profile-bottom">
                                <button onClick={logOut}>
                                    Выйти
                                    <Arrow />
                                </button>
                            </div>
                        </div>
                    </div>       
                </Row>
            </Row>
        )
    }

    return (
        <Row className='header'>
            <Row className='header__left' justyfy='flex-start'>
            </Row>
            <img alt='logo' className='header__logo' src={Logo} />
            <Row className='header__right' justyfy='flex-end'>
                <Popup content={<RegistrationPopup />} classes='registration'>
                    <button className='account'>
                        {user.isLoading && loader}
                        <User />
                    </button>
                </Popup>         
            </Row>
        </Row>
    )
}

export default Header
