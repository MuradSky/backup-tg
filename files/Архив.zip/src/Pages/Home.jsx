import './Home.scss';
import { lazy, Suspense } from 'react';

import Column from 'Components/common/Column';
import Header from 'Components/Header/Header';
import FunExpress from 'Components/FunExpress/FunExpress';

const Dashboard = lazy(()=> import('Components/Dashboard/Dashboard'));
const Results = lazy(()=> import('Components/Results/Results'));

const Home = () => {
    return (
        <div className="app">
            <Column align='center' className="app__wrapper">
                <Header />
                <FunExpress />
                <Suspense fallback={null}>
                    <Dashboard />
                    <Results />
                </Suspense>
            </Column>
        </div>
    );
}

export default Home;
