import axios from 'axios';

axios.defaults.baseURL = process.env.REACT_APP_BACKEND_API ?? '/';
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';