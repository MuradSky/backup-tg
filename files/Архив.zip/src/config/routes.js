const routes = {
    'auth.password': '/api/v1/auth/password',
    'auth.login': '/api/v1/auth/login',
    'auth.logout': '/api/v1/auth/logout',
    'auth.refresh': '/api/v1/auth/refresh',

    'user': '/api/v1/user',
    'products': '/api/v1/products',
    'sale': '/api/v1/sale',
}

export const getApiRoute = (endpoint, query) => {
    return routes[endpoint]
}