export const priceFormatter = (num, separator=" ") => {
    return String(num).replace(/\B(?=(\d{3})+(?!\d))/g, separator);
}

export const isDisableFormik = ({ values, errors }) => {
    return !!Object.keys(values).find(k => !values[k]) || !!Object.keys(errors).find(k => !!errors[k]);
}

export const isErrorFormik = ({ touched, errors }, name) => {
    return (touched[name] && errors[name]);
}