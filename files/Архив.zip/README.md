# React + CRA 
### Стек пректа
-  React
-  Redux-Toolkit
-  styled-components
-  Oбращения к API - axios
-  SASS/SCSS

# Запуск проекта npm + node.js
Необходимая версия ноды `latest`, или `v20.15.1` и выше.

#### Установка модулей и зависимостей

```
npm i
```

## Package.json

-   `npm run start` - Запуск React.js в режиме разработки
-   `npm run build` - Сборка продакшн бандла в prod окружении, артефакты сборки складываются в
    директорию _build_
## .env

#### Переменная апи

```
REACT_APP_BACKEND_API=[вставьте путь к апи, к которому хотите подключиться.]
```